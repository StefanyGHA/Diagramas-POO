class Sesion {
    constructor(usuario, pass, bdusuario, bdpwd){
        this.usuario=usuario
        this.pass= pass
        this.bdusuario=bdusuario
        this.bdpwd=bdpwd
    }

    validar() {
        if (this.usuario === this.bdusuario && this.pass === this.bdpwd) {
            alertify.success('Inicio de sesión exitoso')
            window.location.href = 'registro.html'
        } else if (this.usuario !== this.bdusuario && this.pass === this.bdpwd) {
            alertify.error('Usuario incorrecto')
        } else if (this.usuario === this.bdusuario && this.pass !== this.bdpwd) {
            alertify.error('Contraseña incorrecta')
        } else {
            alertify.error('Las credenciales no son correctas')
        }
    }
}


class usuario extends Sesion{
    constructor(usuario, pass, bdusuario, bdpwd){
        super(usuario, pass, bdusuario, bdpwd)
    }
}

function login (){
    let user = document.getElementById('user').value
    let pwd = document.getElementById('pwd').value

    Consulta = new usuario(user,pwd,'William','123')
    Consulta.validar()

}
function guardarUsuario(nombre, fechaNacimiento, genero, departamento, ciudad) {
    let tarjetaUsuario = document.createElement('div')
    tarjetaUsuario.classList.add('tarjeta-usuario')

    tarjetaUsuario.innerHTML = `
        <h2>${nombre}</h2>
        <p><strong>Fecha de Nacimiento:</strong> ${fechaNacimiento}</p>
        <p><strong>Género:</strong> ${genero}</p>
        <p><strong>Departamento:</strong> ${departamento}</p>
        <p><strong>Ciudad:</strong> ${ciudad}</p>
    `
    let contenedorUsuarios = document.getElementById('usuariosRegistrados')
    contenedorUsuarios.appendChild(tarjetaUsuario)
}

document.getElementById('registroForm').addEventListener('submit', function(event) {
    event.preventDefault()

    let nombre = document.getElementById('nombre').value
    let fechaNacimiento = document.getElementById('fechaNac').value
    let genero = document.getElementById('genero').value;
    let departamento = document.getElementById('departamento').value
    let ciudad = document.getElementById('ciudad').value

    guardarUsuario(nombre, fechaNacimiento, genero, departamento, ciudad)

    this.reset();
});



